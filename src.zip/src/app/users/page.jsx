import getUserData from "@/lib/getUserData";


const UsersPage =  async () => { 
        const data = await getUserData()
        console.log(data);
       
            return <div>
            <h2>User Management </h2>
            
        </div>

};

export default UsersPage;