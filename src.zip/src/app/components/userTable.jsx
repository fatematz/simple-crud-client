import { Table } from "@heroui/react";

const usertable = ({users}) => {
    const {name, role, email} = users
    return (
        <Table>
      <Table.ScrollContainer>
        <Table.Content aria-label="Team members" className="min-w-[600px]">
          <Table.Header>
            <Table.Column isRowHeader> name </Table.Column>
            <Table.Column>Role</Table.Column>
            <Table.Column>Status</Table.Column>
            <Table.Column>Email</Table.Column>
          </Table.Header>
          <Table.Body>
            <Table.Row>
              <Table.Cell>{name}</Table.Cell>
              <Table.Cell>{role}</Table.Cell>
              <Table.Cell>Active</Table.Cell>
              <Table.Cell>{email}</Table.Cell>
            </Table.Row>
            
          
          </Table.Body>
        </Table.Content>
      </Table.ScrollContainer>
    </Table>
    );
};

export default usertable;